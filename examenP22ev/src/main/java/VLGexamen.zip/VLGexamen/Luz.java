package VLGexamen;

public class Luz extends Timbre{

}
